package com.learn.employeeservice.employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    private EmployeeRepository employeeRepository;

    @Autowired
    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    List<Employee> findAllEmployees() {
        return employeeRepository.findAll();
    }

    Employee findEmployee(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }
}
