insert into employee(id, name, age, is_active, salary) values(100,'Dhoni', 25, true, 100);
insert into employee(id, name, age, is_active, salary) values(101,'Virat', 35, true, 350);
insert into employee(id, name, age, is_active, salary) values(102,'Sachin', 45, false, 300);
insert into employee(id, name, age, is_active, salary) values(103,'SunilGavaskar', 55, false, 400);
insert into employee(id, name, age, is_active, salary) values(104,'KapilDev', 65, false, 500);
